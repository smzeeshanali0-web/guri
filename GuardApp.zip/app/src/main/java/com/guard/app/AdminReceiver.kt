package com.guard.app

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class AdminReceiver : DeviceAdminReceiver() {
    override fun onPasswordFailed(context: Context, intent: Intent) {
        if (!context.getSharedPreferences("cfg", 0).getBoolean("on", false)) return
        val s = GuardService.instance
        if (s != null) s.snap()
        else Thread { Mailer.sendWithRetry(context.applicationContext, null, null) }.start()
    }
}
