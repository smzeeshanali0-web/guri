package com.guard.app

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.location.Location
import android.location.LocationManager
import android.media.ImageReader
import android.os.*
import android.view.Surface
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class GuardService : Service() {
    companion object { @Volatile var instance: GuardService? = null; @Volatile var last = 0L }

    private val work = HandlerThread("work").apply { start() }
    private val camT = HandlerThread("cam").apply { start() }
    private val h by lazy { Handler(work.looper) }
    private val cb by lazy { Handler(camT.looper) }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("g", "Guard", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "g").setContentTitle("Guard on hai")
            .setSmallIcon(android.R.drawable.ic_lock_lock).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        else startForeground(1, n)
        instance = this
        return START_NOT_STICKY
    }

    override fun onDestroy() { instance = null; work.quitSafely(); camT.quitSafely() }

    fun snap() {
        val now = System.currentTimeMillis()
        if (now - last < 20000) return
        last = now
        h.post {
            val photo = try { capture() } catch (e: Exception) { null }
            val loc = try { location() } catch (e: Exception) { null }
            Mailer.sendWithRetry(this, photo, loc)
        }
    }

    @SuppressLint("MissingPermission")
    private fun capture(): File? {
        val cm = getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
        } ?: cm.cameraIdList.first()
        val ch = cm.getCameraCharacteristics(id)
        val size = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
            .getOutputSizes(ImageFormat.JPEG).filter { it.width <= 1280 }.maxByOrNull { it.width * it.height }!!
        val orient = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 270
        val reader = ImageReader.newInstance(size.width, size.height, ImageFormat.JPEG, 2)
        val out = File(filesDir, "intruder_${System.currentTimeMillis()}.jpg")
        val done = CountDownLatch(1)
        val tex = SurfaceTexture(10).apply { setDefaultBufferSize(640, 480) }
        val dummy = Surface(tex)
        reader.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage()
            if (img != null) {
                try {
                    val b = img.planes[0].buffer
                    val bytes = ByteArray(b.remaining()); b.get(bytes); out.writeBytes(bytes)
                } finally { img.close() }
                done.countDown()
            }
        }, cb)

        var cam: CameraDevice? = null
        val opened = CountDownLatch(1)
        cm.openCamera(id, object : CameraDevice.StateCallback() {
            override fun onOpened(c: CameraDevice) { cam = c; opened.countDown() }
            override fun onDisconnected(c: CameraDevice) { c.close(); opened.countDown() }
            override fun onError(c: CameraDevice, e: Int) { c.close(); opened.countDown() }
        }, cb)
        opened.await(5, TimeUnit.SECONDS)
        val c = cam ?: return null

        var sess: CameraCaptureSession? = null
        val ready = CountDownLatch(1)
        @Suppress("DEPRECATION")
        c.createCaptureSession(listOf(dummy, reader.surface), object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) { sess = s; ready.countDown() }
            override fun onConfigureFailed(s: CameraCaptureSession) { ready.countDown() }
        }, cb)
        ready.await(5, TimeUnit.SECONDS)
        val s = sess
        if (s == null) { c.close(); return null }

        val pv = c.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply { addTarget(dummy) }
        s.setRepeatingRequest(pv.build(), null, cb)
        Thread.sleep(1500)
        val st = c.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
            addTarget(reader.surface); set(CaptureRequest.JPEG_ORIENTATION, orient)
        }
        s.capture(st.build(), null, cb)
        done.await(5, TimeUnit.SECONDS)
        s.close(); c.close(); reader.close(); dummy.release(); tex.release()
        return if (out.exists() && out.length() > 0) out else null
    }

    @SuppressLint("MissingPermission")
    private fun location(): Location? {
        val lm = getSystemService(LocationManager::class.java)
        var res: Location? = null
        if (Build.VERSION.SDK_INT >= 30) {
            val l = CountDownLatch(1)
            val prov = if (lm.isProviderEnabled("network")) "network" else "gps"
            lm.getCurrentLocation(prov, null, mainExecutor) { res = it; l.countDown() }
            l.await(10, TimeUnit.SECONDS)
        }
        if (res == null) res = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
        return res
    }
}
