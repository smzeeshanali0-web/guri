package com.guard.app

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class LockGuardService : AccessibilityService() {
    private val bad = setOf(
        "power off", "restart", "shut down", "shutdown", "reboot", "power off & restart",
        "airplane mode", "flight mode", "wi-fi", "wifi", "internet", "mobile data", "mobile network"
    )

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (!getSharedPreferences("cfg", 0).getBoolean("on", false)) return
        val km = getSystemService(KeyguardManager::class.java)
        if (!km.isKeyguardLocked) return
        val cls = e.className?.toString() ?: ""
        val hit = cls.contains("GlobalActions", true) || cls.contains("PowerMenu", true) ||
            scan(rootInActiveWindow, 0)
        if (hit) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    private fun scan(n: AccessibilityNodeInfo?, depth: Int): Boolean {
        if (n == null || depth > 12) return false
        val t = n.text?.toString()?.trim()?.lowercase()
        val d = n.contentDescription?.toString()?.trim()?.lowercase()
        if ((t != null && t in bad) || (d != null && d in bad)) return true
        for (i in 0 until n.childCount) if (scan(n.getChild(i), depth + 1)) return true
        return false
    }

    override fun onInterrupt() {}
}
