package com.guard.app

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("cfg", 0)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 100, 40, 40) }
        fun et(hint: String, key: String, pw: Boolean = false) = EditText(this).apply {
            this.hint = hint; setText(p.getString(key, ""))
            if (pw) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            root.addView(this)
        }
        val from = et("Gmail address (bhejne wala)", "from")
        val pass = et("Gmail App Password (16 letters)", "pass", true)
        val to = et("Photo kis email par aye (khali = wohi)", "to")
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() }; root.addView(this) }
        fun save() = p.edit().putString("from", from.text.toString().trim())
            .putString("pass", pass.text.toString().replace(" ", ""))
            .putString("to", to.text.toString().trim()).apply()

        btn("1. Permissions do (camera, location, notification)") {
            requestPermissions(arrayOf(android.Manifest.permission.CAMERA,
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                "android.permission.POST_NOTIFICATIONS"), 1)
        }
        btn("2. Device Admin ON karo") {
            startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java)))
        }
        btn("3. Accessibility ON karo (power menu/WiFi/airplane block)") {
            startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Installed apps > Guard > ON", Toast.LENGTH_LONG).show()
        }
        btn("4. Protection START") {
            save(); p.edit().putBoolean("on", true).apply()
            startForegroundService(Intent(this, GuardService::class.java))
            Toast.makeText(this, "Protection chalu", Toast.LENGTH_SHORT).show()
        }
        btn("Protection STOP") {
            p.edit().putBoolean("on", false).apply()
            stopService(Intent(this, GuardService::class.java))
        }
        btn("TEST: abhi photo + email bhejo") {
            save()
            val s = GuardService.instance
            if (s == null) Toast.makeText(this, "Pehle Protection START karo", Toast.LENGTH_LONG).show()
            else { GuardService.last = 0; s.snap(); Toast.makeText(this, "Bhej raha hoon, 1 minute mein email dekho", Toast.LENGTH_LONG).show() }
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
